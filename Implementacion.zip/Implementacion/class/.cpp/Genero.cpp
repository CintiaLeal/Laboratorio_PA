#include "class/.h/Genero.h"

Genero::Genero(){}
