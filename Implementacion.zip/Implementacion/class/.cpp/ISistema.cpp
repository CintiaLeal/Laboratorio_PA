#include "../../class/.h/ISistema.h"

ISistema::~ISistema(){} //Destructor