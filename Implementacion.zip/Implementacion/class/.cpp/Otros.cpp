#include "class/.h/Otros.h"

Otros::Otros(){}