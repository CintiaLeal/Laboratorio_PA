#include "class/.h/Plataforma.h"

Plataforma::Plataforma(){}